function [er0,er1,er2,er3,t1,t2,t3,t4]=compare_perspline(N,P)

% [er0,er1,er2,er3,t1,t2,t3,t4]=compare_perspline(N,P) : 
% comparison between perspline, spline, perspline_mc
% input
% N : length of datas (=5000 if isemtpty)
% P : numbers of loops (=100 if isemtpty)
% output :
% er0: error between perspline and perspline_mc
% er1: error for perspline_mc
% er2: error for spline
% er3: error for perspline
% t1 : measure elapsed time for perspline_mc
% t2 : measure elapsed time for spline (without loops)
% t3 : measure elapsed time for perspline(withtout loops)
% t4 : measure elapsed time for perspline (with loops)

if nargin==0|isempty(N)
    N=5000;
end
if nargin<=1|isempty(P)
    P=100;
end
x=1:N;
Ng=5e3;
Y=rand(P,N-1);
y=[Y,Y(:,1)];
t=linspace(x(1),x(N),Ng);
er0=0;
for i=1:P
    er0=max([er0,abs(perspline_mc(x,y(i,:),t)-perspline(x,y(i,:),t))]);
end
er1=0;
tic;
for i=1:P
    er1=max([er1,abs(y(i,:)-perspline_mc(x,y(i,:),x))]);
end
t1=toc;
tic;
er2=max(max(abs(y-spline(x,y,x))));
t2=toc;
tic;
er3=max(max(abs(y-perspline(x,y,x))));
t3=toc;
tic;
for i=1:P
    er1=max([er1,abs(y(i,:)-perspline(x,y(i,:),x))]);
end
t4=toc;