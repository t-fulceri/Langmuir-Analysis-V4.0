function [x,y,teste,testcroi]=testgroperpchip(N,nmax)

% gros test de perpchip
%  [x,y,teste,testcroi]=testgroperpchip(N,nmax) 

i=0;
testt=1;
while (testt)
    [teste,testlo,xd,yd]=testperpchip(N);
    i=i+1;
    testt=(i<=nmax)&(testlo);
end
if i<=nmax-1
    x=xd;
    y=yd;
    [teste,testcroi]=testperpchip(N,x,y);
else
    x=[];
    y=[];
    teste=[];
    testcroi=[];
end