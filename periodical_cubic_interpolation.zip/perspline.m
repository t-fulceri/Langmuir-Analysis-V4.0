function v = perspline(x,y,xx)
%PERSPLINE  Cubic spline data interpolation..
% this function is exactly the same as spline except that the data and results are periodic :
% y(1)=y(end) and the slope at x(1) and x(end) are equal
% See for example chapter 3 (exercice 3.13 p. 114,115) of 
%   Numerical Computing with MATLAB, SIAM, 2004
%   by Cleve B. Moler
%
% See also 
% http://www.mathworks.com/matlabcentral/fileexchange/4822-using-numerical-computing-with-matlab-in-the-classroom/ 
% where the file perspline is NOT provided
%
%
%   PP = PERSPLINE(X,Y) provides the piecewise polynomial form of the 
%   cubic spline interpolant to the data values Y at the data sites X,
%   for use with the evaluator PPVAL and the spline utility UNMKPP.
%   X must be a vector.
%   If Y is a vector, then Y(j) is taken as the value to be matched at X(j), 
%   hence Y must be of the same length as X  -- see below for an exception
%   to this.
%   If Y is a matrix or ND array, then Y(:,...,:,j) is taken as the value to
%   be matched at X(j),  hence the last dimension of Y must equal length(X) --
%   It is mandatory that Y(:,...,:,1)=Y(:,...,:,end)
%
%   YY = PERSPLINE(X,Y,XX) is the same as  YY = PPVAL(PERSPLINE(X,Y),XX), thus
%   providing, in YY, the values of the interpolant at XX.  
%
%
%   See the help of function spline
%
%
%   Example:
%
%  a)
%     x = -3:3;
%     y = [-1 -1 -1 0 1 1 -1];
%     t = -3:.01:3;
%     plot(x,y,'o',t,[perspline(x,y,t);spline(x,y,t)])
%     legend('data','perspline','spline',0)
%
%  b) teste=testperspline(15)
%
%
%   Class support for inputs x, y, xx:
%      float: double, single
%
%   See also INTERP1, PCHIP, PPVAL, UNMKPP, MKPP, SPLINES (The Spline Toolbox).
%
%   Original file "spline.m" : Carl de Boor 7-2-86
%                              Copyright 1984-2004 The MathWorks, Inc.
%                              $Revision: 5.18.4.4 $  $Date: 2004/12/06 16:35:53 $
%   Modified by J�r�me Bastien $Date 2014/04/08
%                jerome.bastien@univ-lyon1.fr
%                http://utbmjb.chez-alice.fr/

v=[];

% Check that data are acceptable and, if not, try to adjust them appropriately
[x,y,sizey,endslopes] = chckxy(x,y);
n = length(x); yd = prod(sizey);
% Check moreover, that data are periodic
if max(abs(y(:,1)-y(:,end)))~=0
    error('The data should be periodic')
end

% Generate the cubic spline interpolant in ppform

dd = ones(yd,1); dx0 = diff(x); divdif0 = diff(y,[],2)./dx0(dd,:);

if n==2
    % the interpolant is a (constant) straight line
    pp=mkpp(x,y(:,1),sizey);
else
    % dx and divdif are artificially increased by periodicity
    dx=[dx0(end),dx0,dx0(1)];
    divdif=[divdif0(:,end),divdif0,divdif0(:,1)];
    % set up the sparse, (non-)tridiagonal, linear system b = ?*c.' for the slopes
    b=3*(dx(dd,2:n+1).*divdif(:,1:n)+divdif(:,2:n+1).*dx(dd,1:n));
    u=[dx(3:n+1),0];
    v=2*(dx(2:n+1)+dx(1:n));
    w=[0,dx(1:n-1)];
    c=spdiags([u;v;w].',[-1 0 1],n,n);
    if n==3
        auxi=sum(dx0);
        c(3,2)=auxi;
        c(1,2)=auxi;
    else
        c(n,2)=dx(n);
        c(1,n-1)=dx(2);
    end
    % sparse linear equation solution for the slopes
    mmdflag = spparms('autommd');
    spparms('autommd',0);
    %   ATTENTION !!!!!!!
    %s=b/c;
    s=b/(c.');
    spparms('autommd',mmdflag);
    % construct piecewise cubic Hermite interpolant
    % to values and computed slopes
    pp = pwch(x,y,s,dx0,divdif0); pp.dim = sizey;
end


if nargin==2, v = pp; else v = ppval(pp,xx); end


% -------------------------------------------------------
   
% function : \MATLAB\R2008b\toolbox\matlab\polyfun\private   

function [x,y,sizey,endslopes] = chckxy(x,y)
%CHCKXY check and adjust input for SPLINE and PCHIP
%   [X,Y,SIZEY] = CHCKXY(X,Y) checks the data sites X and corresponding data
%   values Y, making certain that there are exactly as many sites as values,
%   that no two data sites are the same, removing any data points that involve 
%   NaNs, reordering the sites if necessary to ensure that X is a strictly
%   increasing row vector and reordering the data values correspondingly,
%   and reshaping Y if necessary to make sure that it is a matrix, with Y(:,j)
%   the data value corresponding to the data site X(j), and with SIZEY the
%   actual dimensions of the given values. 
%   This call to CHCKXY is suitable for PCHIP.
%
%   [X,Y,SIZEY,ENDSLOPES] = CHCKXY(X,Y) also considers the possibility that
%   there are two more data values than there are data sites.
%   If there are, then the first and the last data value are removed from Y
%   and returned separately as ENDSLOPES. Otherwise, an empty ENDSLOPES is
%   returned.  This call to CHCKXY is suitable for SPLINE.
%
%   See also PCHIP, SPLINE.

%   Copyright 1984-2003 The MathWorks, Inc.

% make sure X is a vector:
if length(find(size(x)>1))>1 
  error('MATLAB:chckxy:XNotVector','X must be a vector.') 
end

% ensure X is real
if any(~isreal(x)) 
  error('MATLAB:chckxy:XComplex','The X vector should have real elements.') 
end

% deal with NaN's among the sites:
nanx = find(isnan(x));
if ~isempty(nanx)
   x(nanx) = [];
   warning('MATLAB:chckxy:nan','All data points with NaN as their site will be ignored.')
end

n=length(x);
if n<2 
  error('MATLAB:chckxy:NotEnoughPts','There should be at least two data points.') 
end

% re-sort, if needed, to ensure strictly increasing site sequence:
x=x(:).'; 
dx = diff(x);

if any(dx<0), [x,ind] = sort(x); dx = diff(x); else ind=1:n; end

if ~all(dx), error('MATLAB:chckxy:RepeatedSites','The data sites should be distinct.'), end

% if Y is ND, reshape it to a matrix by combining all dimensions but the last:
sizey = size(y);


while length(sizey)>2&&sizey(end)==1, sizey(end) = []; end


yn = sizey(end); 
sizey(end)=[]; 
yd = prod(sizey);

if length(sizey)>1
   y = reshape(y,yd,yn);
else
   % if Y happens to be a column matrix, change it to the expected row matrix.
   if yn==1
       yn = yd;
       y = reshape(y,1,yn); 
       yd = 1; 
       sizey = yd;
   end
end

% determine whether not-a-knot or clamped end conditions are to be used:
nstart = n+length(nanx);
if yn==nstart
   endslopes = [];
elseif nargout==4&&yn==nstart+2
   endslopes = y(:,[1 n+2]); y(:,[1 n+2])=[];
   if any(isnan(endslopes))
      error('MATLAB:chckxy:EndslopeNaN','The endslopes cannot be NaN.')
   end
   if any(isinf(endslopes))
       error('MATLAB:chckxy:EndslopeInf','The endslopes cannot be Inf.')
   end
else
   error('MATLAB:chckxy:NumSitesMismatchValues',...
        ['The number of sites, ' int2str(nstart), ...
        ', is incompatible with the number of values, ' int2str(yn) '.'])
end

% deal with NaN's among the values:
if ~isempty(nanx)
    y(:,nanx) = [];
end

y=y(:,ind);
nany = find(sum(isnan(y),1));
if ~isempty(nany)
   y(:,nany) = []; x(nany) = [];
   warning('MATLAB:chckxy:IgnoreNaN','All data points with NaN in their value will be ignored.')
   n = length(x);
   if n<2 
     error('MATLAB:chckxy:NotEnoughPts', 'There should be at least two data points.') 
   end
end



