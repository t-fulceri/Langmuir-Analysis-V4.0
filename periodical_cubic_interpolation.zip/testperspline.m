function teste=testperspline(N)

% teste=testperspline(N) :
% test of function perspline.
% random points (x_i,y_i) are choosen (with y_1=y_n)
% and S, function interpolating of (x_i,y_i) is plotted with its derivative.
% A number teste is calculated. This number is close to zero when
% the function S satisfies :
% S(x_i)=y_i
% S, S' and S'' are continuous in x_i
% S(x_1-0)=S(x_n+0)
% S'(x_1-0)=S'(x_n+0)
% S''(x_1-0)=S''(x_n+0)

Ng=1000;
if nargin<=1
    x=sort(rand(1,N+1));
    Y=rand(1,N);
    if N>=3
        p=floor((N+1)/2);
        Y(p+1)=Y(p);
    end
    y=[Y,Y(1)];
else
    x=x0;
    y=y0;
end
xm=min(x);
xM=max(x);
xg=unique(sort([x,linspace(xm,xM,Ng)]));
pp=perspline(x,y);
ppd=ppder(pp);
ppdd=ppder(ppd);
ppc=spline(x,y);
ppdc=ppder(ppc);
ppddc=ppder(ppdc);
subplot(3,1,1);
plot(xg,ppval(pp,xg),xg,ppval(ppc,xg),x,y,'o');
legend('perspline','spline','data',0);
title('function');
subplot(3,1,2);
plot(xg,ppval(ppd,xg),xg,ppval(ppdc,xg));
legend('perspline','spline',0);
title('derivative');
subplot(3,1,3);
plot(xg,ppval(ppdd,xg),xg,ppval(ppddc,xg));
legend('perspline','spline',0);
title('twice derivative');
teste=verifie_pp(pp,2,1,x,y);