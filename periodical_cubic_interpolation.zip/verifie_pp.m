function [ec,croi]=verifie_pp(pp,ndeg,per,x,y)

% v�rification de la r�gularit� (et de la croissance) du polyn�me pp
%
% *********************************************************
% [ec,croi]=verifie_pp(pp,ndeg,per) :
% pp est un polyn�me par morceaux. ec est un nombre qui nul, signifie que
% pp est de classe Ck pour 0<=k<=ndeg en x_i=pp.breaks
% le cas �ch�ant, la continuit� est v�rifi�e par p�riodicit� en x1 et x_n.
% le cas �ch�ant, la croissance de pp est donn�e sur chaque intervalle.
%
%
%  * Variables d'entr�e :
%     * pp : polyn�me par morceaux
%  * Variables d'entr�e optionnelle :
%     * ndeg=0 par d�faut
%     * per=0 par d�faut (=1 pour v�rifier la p�riodicit�)
%  * Variables d'entr�e optionnelles
%     * deux vecteurs x et y pour v�rifier aussi que pp(x_i)=y_i
%
%  * Variables de sortie :
%     * ec : nombre nul en th�orie
%  * Variables de sortie optionnelle
%     * croi : tableau contenant pour chaque intervalle
%       1 si croissant
%       -1 si d�croissant
%       0 si constant
%       2 sinon
%
%   Example:
%
% a)
%     x = -3:4;
%     y = [-1 -1 -1 0 1 1 1 -1];
%     [ec,croi]=verifie_pp(perpchip(x,y),1,1,x,y)
% b)
%     x = -3:4;
%     y = [-1 -1 -1 0 1 1 1 1];
%     [ec,croi]=verifie_pp(pchip(x,y),1,0,x,y)
%     ec=verifie_pp(spline(x,y),2,0,x,y)
%
% ************ Fonctions auxiliaires utilis�es ************
% - croisloc (nich�e)
%
% *********************************************************
%
%
%
% 2014 by          J�r�me BASTIEN
%                  Universit� Claude Bernard Lyon I, UFRSTAPS, Laboratoire CRIS, Villeurbanne
%                  E-Mail : jerome.bastien@univ-lyon1.fr

nin=nargin;
nout=nargout;
if nin<=1|isempty(ndeg)
    ndeg=0;
end
if nin<=2|isempty(per)
    per=0;
end
if nin<=3|isempty(x)
    x=[];
end
n=length(pp.breaks);
s=0;
ppq=pp;
if ndeg==0&nout>=2
    ppd=ppder(pp);
end
for j=0:ndeg
    if per
        x1=polyval(ppq.coefs(1,:),0);
        x2=polyval(ppq.coefs(n-1,:),ppq.breaks(n)-ppq.breaks(n-1));
        s=max([s,abs(x1-x2)]);
    end
    for i=2:n-1
        x1=polyval(ppq.coefs(i,:),0);
        x2=polyval(ppq.coefs(i-1,:),ppq.breaks(i)-ppq.breaks(i-1));
        s=max([s,abs(x1-x2)]);
    end
    if j<=ndeg-1
        ppq=ppder(ppq);
        if j==0&nout>=2
            ppd=ppq;            
        end
    end
end
if ~isempty(x)
    s=max([s,abs(y-ppval(pp,x))]);
end
ec=s;
if nargout>=2
    croi=zeros(1,n-1);
    for i=1:n-1
        f=pp.coefs(i,:);
        df=ppd.coefs(i,:);
        croi(i)=croisloc(f,df,0,pp.breaks(i+1)-pp.breaks(i));
    end
end



% ------------------------------------------------------------------------

function croi=croisloc(P,dP,a,b,testepsi)


% croissance d'une fonction polyn�miale
%
% *********************************************************
% croi=croisloc(P,dP,a,b) :
%  * Variables d'entr�e :
%     * P et dP : polyn�me et sa d�riv�e
%     * a et b r�els 
%  * Variables d'entr�e optionnelle :
%     * testepsi>=0 : seuil de confusion des z�ros de la d�riv�e avec a ou b
%                    (�gal � 1e-10 par d�faut)
%  * Variables de sortie  
%     * croi : 
%       1 si P croissant sur [a,b]
%       -1 si d�croissant sur [a,b]
%       0 si constant  ur [a,b]
%       2 sinon
%
% ************ Fonctions auxiliaires utilis�es ************
% aucune
%
% *********************************************************
%
%
% 2014 by          J�r�me BASTIEN
%                  Universit� Claude Bernard Lyon I, UFRSTAPS, Laboratoire CRIS, Villeurbanne
%                  E-Mail : jerome.bastien@univ-lyon1.fr

if nargin<=4|isempty(testepsi)
    testepsi=1e-10;
end

if max(abs(P))==0
    croi=0;
else
    Z=roots(dP);
    indd=abs(imag(Z))<=eps;
    if sum(indd)>=1
        Z=Z(indd);
        indd=(Z>=a)&(Z<=b);
        Z=Z(indd);
    end
    if sum(indd)==0
        croi=sign(polyval(P,b)-polyval(P,a));
    else
        Z=(sort(Z)).';
        if testepsi>0
            if ~isempty(Z)
                if Z(1)<=a+testepsi;
                    Z(1)=[];
                end
            end
            if ~isempty(Z)
                if Z(end)>=b-testepsi;
                    Z(end)=[];
                end
            end
        end
        u=sign(diff(polyval(P,unique(sort([a,b,Z.'])))));
        indp=(u==1);
        indm=(u==-1);
        croi=2;
        if sum(indp)==0
            croi=-1;
        end
        if sum(indm)==0
            croi=1;
        end
    end
% AAAA attention virer aussi les z�ros de la d�riv�e � testespi pr�s en
% utlisant un truc du genre (extrait de altitude_coupe)
% auxiz=sort(diff(Z));
% if testepsi>=0&isempty(auxiz)
% u=(abs(auxiz)<=testepsi);
% Q=find(u==0);
% Nbb=[1,Q(1:(Nq-1))+1];
% Z=Z(Nbb);
% end
end

